export const usersSelector = state => state.users.users;
export const adminsSelector = state => state.users.admins;