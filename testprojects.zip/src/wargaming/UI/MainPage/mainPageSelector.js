export const selectElementsSelector = state => state.mainPage.selectElements;
export const selectButtonSelector = state => state.mainPage.selectButton;